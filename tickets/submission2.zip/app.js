import { Application, Router } from "https://deno.land/x/oak@v9.0.1/mod.ts";
import renderMiddleware from "./middlewares/renderMiddleware.js";
import * as ticketService from "./services/ticketService.js"

const app = new Application();
const router = new Router();

app.use(renderMiddleware);

const listTickets = async ({ render }) => {
  render("index.eta", { tickets: await ticketService.findAll() });
} 

const addTicket = async ({ request, response }) => {
  const body = request.body();
  const params = await body.value;

  await ticketService.add(params.get("content"));

  response.redirect("/tickets");
};


router.get("/tickets", listTickets)
  .post("/tickets", addTicket);


app.use(router.routes());

if (!Deno.env.get("TEST_ENVIRONMENT")) {
  app.listen({ port: 7777 });
}

export default app;
